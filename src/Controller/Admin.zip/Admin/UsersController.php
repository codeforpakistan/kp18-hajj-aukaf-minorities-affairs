<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

use Cake\Auth\DefaultPasswordHasher;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    public function isAuthorized($user) {
         if ($this->Auth->user('role_id') == 1) {
            return true;
        }
        
        
    }
    
    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    private function image_validation($image_details = null) {
        $extentions = array('jpg', 'JPG', 'PNG', 'png', 'jpeg', 'JPEG', 'gif', 'GIF', 'svg', 'SVG');
        $continue = 1;
        $error = '';
        
            
            $img_ext = pathinfo($image_details['name'], PATHINFO_EXTENSION);
           
            if (!in_array($img_ext, $extentions)) {
                $error = 'only image can be uploaded';
                $continue = 0;
                return $error;
            }
            if ($image_details['size'] > 1000000) {
                $error = 'Image size is too big';
                $continue = 0;
                return $error;
            }
       
        if ($continue == 1) {
            return $continue;
        }
//        exit();
    }
 public function login() {
         $this->viewBuilder()->layout('');
       if ($this->request->is('post')) {
          
           $user = $this->Auth->identify();
           
           if ($user) {
               $this->Auth->setUser($user);
               
               return $this->redirect($this->Auth->redirectUrl());
           }
            
           $this->Flash->error(__('Invalid email or password, try again'));
       }
       else{
           $this->Flash->error(__('not found'));
       }
       
   }

   public function logout() {
       return $this->redirect($this->Auth->logout());
   }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->viewBuilder()->layout('admin'); 
        
       $users = $this->Users->find('all',[
            'contain' => ['Roles']
        ])->toArray();
        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {    $this->viewBuilder()->layout('admin');
        $user = $this->Users->get($id, [
            'contain' => ['Roles']
        ]);

        $this->set('user', $user);
    }

    
    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {   $this->viewBuilder()->layout('admin');
        $user = $this->Users->newEntity();
        
        if ($this->request->is('post')) {
            if ($this->request->data['photo'] <> '') {
              
                $valid_image = $this->image_validation($this->request->data['photo']);
               $u_img=$this->request->data['photo'];
               
                if ($valid_image == 1) {
                    debug($this->request->data);
                     $get_ext = pathinfo($u_img['name'], PATHINFO_EXTENSION);

                $new_name =  '0-' . date('ymdhis') . '.' . $get_ext;
                $path = WWW_ROOT . 'img' . DS . 'applicants' . DS . $new_name;

                move_uploaded_file($u_img['tmp_name'], $path);
                $this->request->data['photo']=$new_name;
                //debug($this->request->data['photo']);
                $hasher = new DefaultPasswordHasher();
                $this->request->data['password'] = $hasher->hash($this->request->data['password']);
                $user = $this->Users->patchEntity($user, $this->request->getData());
            
                
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
                                    
                                    
                }
                
           
            
        }
    }
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles'));
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {   $this->viewBuilder()->layout('admin');
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
             if ($this->request->data['photo'] <> '') {
              
                $valid_image = $this->image_validation($this->request->data['photo']);
               $u_img=$this->request->data['photo'];
               
                if ($valid_image == 1) {
                    debug($this->request->data);
                     $get_ext = pathinfo($u_img['name'], PATHINFO_EXTENSION);

                $new_name =  '0-' . date('ymdhis') . '.' . $get_ext;
                $path = WWW_ROOT . 'img' . DS . 'applicants' . DS . $new_name;

                move_uploaded_file($u_img['tmp_name'], $path);
                $this->request->data['photo']=$new_name;
             $hasher = new DefaultPasswordHasher();
            $this->request->data['password'] = $hasher->hash($this->request->data['password']);
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
                }
        }
        }
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
