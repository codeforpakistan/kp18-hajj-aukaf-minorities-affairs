<?php
namespace App\Controller\admin;

use App\Controller\AppController;

/**
 * Institutes Controller
 *
 * @property \App\Model\Table\InstitutesTable $Institutes
 *
 * @method \App\Model\Entity\Institute[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InstitutesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {   $this->viewBuilder()->layout('admin');
         
        $institutes = $this->Institutes->find('all',[
             'contain' => ['InstituteTypes', 'Cities']
        ])->toArray();

        $this->set(compact('institutes'));
    }

    /**
     * View method
     *
     * @param string|null $id Institute id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {   $this->viewBuilder()->layout('admin');
        $institute = $this->Institutes->get($id, [
            'contain' => ['InstituteTypes', 'Cities', 'Qualifications']
        ]);

        $this->set('institute', $institute);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {   $this->viewBuilder()->layout('admin');
        $institute = $this->Institutes->newEntity();
        if ($this->request->is('post')) {
            $institute = $this->Institutes->patchEntity($institute, $this->request->getData());
            if ($this->Institutes->save($institute)) {
                $this->Flash->success(__('The institute has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The institute could not be saved. Please, try again.'));
        }
        $instituteTypes = $this->Institutes->InstituteTypes->find('list', ['limit' => 200,'keyField'=>'id','valueField'=>'type']);
        $cities = $this->Institutes->Cities->find('list', ['limit' => 200]);
        $this->set(compact('institute', 'instituteTypes', 'cities'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Institute id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {   $this->viewBuilder()->layout('admin');
        $institute = $this->Institutes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $institute = $this->Institutes->patchEntity($institute, $this->request->getData());
            if ($this->Institutes->save($institute)) {
                $this->Flash->success(__('The institute has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The institute could not be saved. Please, try again.'));
        }
        $instituteTypes = $this->Institutes->InstituteTypes->find('list', ['limit' => 200,'keyField'=>'id','valueField'=>'type']);
        $cities = $this->Institutes->Cities->find('list', ['limit' => 200]);
        $this->set(compact('institute', 'instituteTypes', 'cities'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Institute id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $institute = $this->Institutes->get($id);
        if ($this->Institutes->delete($institute)) {
            $this->Flash->success(__('The institute has been deleted.'));
        } else {
            $this->Flash->error(__('The institute could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
